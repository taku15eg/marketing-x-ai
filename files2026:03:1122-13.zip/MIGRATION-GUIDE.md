# MIGRATION-GUIDE.md — Claude Code実装移行ガイド

> このガイドに従って、既存の実装をv8-enriched仕様に修正する。

---

## 1. 修正の優先順位

### CRITICAL（これがないと価値が半減）
1. types.ts のデータ構造変更
2. 根拠チェーン4ステップの実装
3. Before/After表示の追加
4. 依頼パックのデザイナー/エンジニア切り替え

### HIGH
5. ブランドカラー統一（#1B3A5C → #2563EB）
6. 期待効果・注意点の表示
7. 実験ノート機能の設計・実装

### MEDIUM
8. ソースタグの表示
9. インタラクティブデモの追加
10. インタビュー引用の追加

---

## 2. types.ts の変更

### 削除する型
```typescript
// 削除: 旧Issue型
export interface Issue {
  priority: number;
  title: string;
  diagnosis: string;
  impact: 'high' | 'medium' | 'low';
  handoff_to: 'designer' | 'engineer' | 'copywriter+designer' | 'marketer';
  brief: HandoffBrief;
  evidence: string;  // これが単一フィールドだったのが問題
}

// 削除: 旧HandoffBrief型
export interface HandoffBrief {
  objective: string;
  direction: string;
  specifics: string;
  constraints: string[];
  qa_checklist: string[];
}
```

### 追加する型
`types-unified.ts` の内容をそのまま `lib/types.ts` に置き換える。

主な変更点:
- `Issue` → `Proposal` にリネーム
- `evidence: string` → `evidence_chain: EvidenceChain` に変更
- `brief` → `briefs: { designer, engineer }` に分離
- `before_after`, `expected_impact`, `caution` を追加
- `ExperimentLog` 型を追加

---

## 3. コンポーネントの変更

### 3.1 IssueCard.tsx → ProposalCard.tsx

**ファイル名変更**: `IssueCard.tsx` → `ProposalCard.tsx`

**構造変更**:

```tsx
// Before (現状)
<div className="card">
  <div className="header">
    <span>{issue.priority}</span>
    <span>{issue.title}</span>
    <span>{issue.impact}</span>
    <span>{issue.handoff_to}</span>
  </div>
  {isExpanded && (
    <div className="detail">
      <p>{issue.diagnosis}</p>
      <p>{issue.evidence}</p>
      <BriefPanel brief={issue.brief} />
    </div>
  )}
</div>

// After (v8-enriched仕様)
<div className="card">
  <div className="header">
    <span className="arrow">›</span>
    <div className="meta">
      <CategoryTag category={proposal.category} />
      <ImpactTag impact={proposal.impact} />
    </div>
    <h3>{proposal.title}</h3>
  </div>
  {isExpanded && (
    <div className="detail">
      {/* このページの文脈 */}
      <ContextSection context={proposal.context} />
      
      {/* 根拠チェーン（4ステップ）★CRITICAL */}
      <EvidenceChainSection chain={proposal.evidence_chain} />
      
      {/* Before / After ★CRITICAL */}
      <BeforeAfterSection beforeAfter={proposal.before_after} />
      
      {/* 期待できる効果 */}
      <ExpectedImpactSection impact={proposal.expected_impact} />
      
      {/* 注意点 */}
      <CautionSection caution={proposal.caution} />
      
      {/* 依頼パック（タブ切り替え）*/}
      <BriefTabs briefs={proposal.briefs} />
    </div>
  )}
</div>
```

### 3.2 新規コンポーネント: EvidenceChainSection

```tsx
// components/EvidenceChainSection.tsx

import type { EvidenceChain } from '@/lib/types';
import SourceTag from './SourceTag';

interface Props {
  chain: EvidenceChain;
}

const STEP_CONFIG = {
  observation: {
    label: '現状',
    icon: 'eye',
    color: '#64748B',
  },
  industry_trend: {
    label: '業界傾向',
    icon: 'chart',
    color: '#7C3AED',
  },
  gap: {
    label: 'ギャップ',
    icon: 'lightning',
    color: '#F59E0B',
  },
  hypothesis: {
    label: '仮説',
    icon: 'lightbulb',
    color: '#2563EB',
  },
};

export default function EvidenceChainSection({ chain }: Props) {
  return (
    <section className="mb-5">
      <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-2">
        <ClipboardIcon className="w-3 h-3" />
        根拠チェーン
      </h4>
      <div className="space-y-3">
        {(['observation', 'industry_trend', 'gap', 'hypothesis'] as const).map((key) => {
          const step = chain[key];
          const config = STEP_CONFIG[key];
          return (
            <div key={key} className="flex gap-3">
              <div
                className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center"
                style={{ backgroundColor: `${config.color}20`, color: config.color }}
              >
                <StepIcon type={config.icon} />
              </div>
              <div className="flex-1">
                <div
                  className="text-xs font-bold mb-1"
                  style={{ color: config.color }}
                >
                  {config.label}
                </div>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {step.text}
                  <SourceTag tag={step.source} />
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
```

### 3.3 新規コンポーネント: BeforeAfterSection

```tsx
// components/BeforeAfterSection.tsx

import type { BeforeAfter } from '@/lib/types';

interface Props {
  beforeAfter: BeforeAfter;
}

export default function BeforeAfterSection({ beforeAfter }: Props) {
  return (
    <section className="mb-5">
      <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">
        Before / After
      </h4>
      <div className="space-y-2">
        <div className="flex gap-2">
          <span className="px-2 py-1 bg-red-50 text-red-700 text-xs font-bold rounded">
            Before
          </span>
          <p className="text-sm text-gray-600 bg-red-50/50 rounded px-3 py-2 flex-1">
            {beforeAfter.before}
          </p>
        </div>
        <div className="flex gap-2">
          <span className="px-2 py-1 bg-green-50 text-green-700 text-xs font-bold rounded">
            After
          </span>
          <p className="text-sm text-gray-700 bg-green-50/50 rounded px-3 py-2 flex-1">
            {beforeAfter.after}
          </p>
        </div>
      </div>
    </section>
  );
}
```

### 3.4 BriefPanel.tsx → BriefTabs.tsx

**ファイル名変更**: `BriefPanel.tsx` → `BriefTabs.tsx`

**機能追加**: デザイナー向け / エンジニア向け のタブ切り替え

```tsx
// components/BriefTabs.tsx

import { useState } from 'react';
import type { DesignerBrief, EngineerBrief } from '@/lib/types';

interface Props {
  briefs: {
    designer: DesignerBrief;
    engineer: EngineerBrief;
  };
}

export default function BriefTabs({ briefs }: Props) {
  const [activeTab, setActiveTab] = useState<'designer' | 'engineer'>('designer');

  return (
    <section>
      <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">
        依頼パック
      </h4>
      
      {/* タブ */}
      <div className="flex gap-1 mb-3">
        <button
          onClick={() => setActiveTab('designer')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            activeTab === 'designer'
              ? 'bg-[#2563EB] text-white'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          デザイナー向け
        </button>
        <button
          onClick={() => setActiveTab('engineer')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            activeTab === 'engineer'
              ? 'bg-[#2563EB] text-white'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          エンジニア向け
        </button>
      </div>

      {/* コンテンツ */}
      <div className="border border-[#2563EB]/20 rounded-xl bg-gradient-to-br from-slate-50 to-white overflow-hidden">
        <div className="bg-[#2563EB] px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DocumentIcon className="w-4 h-4 text-white/80" />
            <span className="text-sm font-semibold text-white">
              {activeTab === 'designer' ? 'デザイナー向け依頼書' : 'エンジニア向け依頼書'}
            </span>
          </div>
          <span className="text-[10px] text-white/60">
            Powered by Publish Gate
          </span>
        </div>

        <div className="p-5">
          {activeTab === 'designer' ? (
            <DesignerBriefContent brief={briefs.designer} />
          ) : (
            <EngineerBriefContent brief={briefs.engineer} />
          )}
        </div>
      </div>
    </section>
  );
}

function DesignerBriefContent({ brief }: { brief: DesignerBrief }) {
  return (
    <div className="space-y-4">
      <BriefSection number={1} title="変更の目的">
        <p className="text-sm text-gray-800">{brief.objective}</p>
      </BriefSection>
      
      <BriefSection number={2} title="変更内容">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-3 py-2 text-left font-medium text-gray-600">対象</th>
              <th className="px-3 py-2 text-left font-medium text-gray-600">Before</th>
              <th className="px-3 py-2 text-left font-medium text-gray-600">After</th>
            </tr>
          </thead>
          <tbody>
            {brief.changes.map((change, i) => (
              <tr key={i} className="border-t border-gray-100">
                <td className="px-3 py-2 text-gray-700">{change.target}</td>
                <td className="px-3 py-2 text-gray-500">{change.before}</td>
                <td className="px-3 py-2 text-gray-900 font-medium">{change.after}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </BriefSection>
      
      <BriefSection number={3} title="チェックリスト">
        <ul className="space-y-2">
          {brief.checklist.map((item, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
              <CheckIcon className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </BriefSection>
    </div>
  );
}

function EngineerBriefContent({ brief }: { brief: EngineerBrief }) {
  return (
    <div className="space-y-4">
      <BriefSection number={1} title="変更箇所">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-3 py-2 text-left font-medium text-gray-600">セレクタ</th>
              <th className="px-3 py-2 text-left font-medium text-gray-600">操作</th>
              <th className="px-3 py-2 text-left font-medium text-gray-600">内容</th>
            </tr>
          </thead>
          <tbody>
            {brief.changes.map((change, i) => (
              <tr key={i} className="border-t border-gray-100">
                <td className="px-3 py-2">
                  <code className="bg-gray-100 px-2 py-0.5 rounded text-xs font-mono text-gray-700">
                    {change.selector}
                  </code>
                </td>
                <td className="px-3 py-2 text-gray-600 capitalize">{change.operation}</td>
                <td className="px-3 py-2 text-gray-900">{change.after}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </BriefSection>
      
      <BriefSection number={2} title="テスト要件">
        <ul className="space-y-2">
          {brief.test_requirements.map((req, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
              <CheckIcon className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
              <span>{req}</span>
            </li>
          ))}
        </ul>
      </BriefSection>
    </div>
  );
}
```

---

## 4. AnalysisResult.tsx の変更

### 変更点

1. `issues` → `proposals` にリネーム
2. `improvement_potential` → `insight` に変更
3. `IssueCard` → `ProposalCard` に変更
4. ページ読み取り結果の表示項目追加（`primary_cta`, `primary_cv`, `target_audience`, `evidence_data`）

```tsx
// Before
{result.issues.map((issue) => (
  <IssueCard key={issue.priority} issue={issue} />
))}

// After
{result.proposals.map((proposal) => (
  <ProposalCard key={proposal.id} proposal={proposal} />
))}
```

---

## 5. ブランドカラー置換

### 一括置換コマンド

```bash
# 全ファイルで #1B3A5C を #2563EB に置換
find src/dashboard -type f \( -name "*.tsx" -o -name "*.ts" -o -name "*.css" \) \
  -exec sed -i 's/#1B3A5C/#2563EB/g' {} \;

# hover色も置換
find src/dashboard -type f \( -name "*.tsx" -o -name "*.ts" -o -name "*.css" \) \
  -exec sed -i 's/#2A5580/#1D4ED8/g' {} \;

# グラデーションの終点も置換
find src/dashboard -type f \( -name "*.tsx" -o -name "*.ts" -o -name "*.css" \) \
  -exec sed -i 's/#2a5a8c/#3B82F6/g' {} \;
```

### 置換対象ファイル（39箇所）

確認済みの置換対象:
- `app/analysis/[id]/page.tsx`
- `app/share/[id]/page.tsx`
- `components/AnalysisResult.tsx`
- `components/IssueCard.tsx` → `ProposalCard.tsx`
- `components/BriefPanel.tsx` → `BriefTabs.tsx`
- `components/LoadingProgress.tsx`
- `components/ShareButton.tsx`
- `components/TabNavigation.tsx`
- `components/PoweredByBadge.tsx`
- `components/ErrorBoundary.tsx`

---

## 6. prompt-builder.ts の変更

Claude APIに送るプロンプトを変更し、新しいJSON構造を出力させる。

### 出力スキーマの変更

```typescript
// 旧出力スキーマ
{
  "issues": [
    {
      "priority": 1,
      "title": "...",
      "diagnosis": "...",
      "evidence": "...",  // 単一フィールド
      "handoff_to": "designer",
      "brief": { ... }
    }
  ]
}

// 新出力スキーマ
{
  "insight": "FVが「チームの時間を見える化」とサービス説明に留まっていて...",
  "proposals": [
    {
      "id": 1,
      "category": "trust",
      "impact": "high",
      "title": "「チームの時間を見える化」を「導入3ヶ月で残業30%削減した方法」に書き換える",
      "context": {
        "business_role": "新規見込み客の獲得入口",
        "page_strengths": ["500社導入", "残業30%削減", "利益率12%改善"],
        "element_role": "「使うとどうなるか」をスクロール前に伝えること"
      },
      "evidence_chain": {
        "observation": {
          "text": "FVのメインコピーは「チームの時間を見える化」。機能名を述べているだけで成果への言及がない。",
          "source": { "type": "fv_text" }
        },
        "industry_trend": {
          "text": "BtoB SaaS LPの上位CVR群ではFVに成果数値を掲載するパターンが主流。",
          "source": { "type": "ai_knowledge" }
        },
        "gap": {
          "text": "導入事例に「残業30%削減」「利益率12%改善」と書いてあるが、FVでは未使用。素材はあるのに配置が最適でない。",
          "source": { "type": "section", "name": "導入事例セクション" }
        },
        "hypothesis": {
          "text": "「何ができるか」は伝わるが「使うとどうなるか」が不在のため、CTA到達前に離脱している可能性が高い。",
          "source": { "type": "estimate" }
        }
      },
      "before_after": {
        "before": "「チームの時間を見える化」— 機能説明のみ。成果が不在。",
        "after": "「導入3ヶ月で残業30%削減した方法」— 導入事例の実績をFVに引き上げ。"
      },
      "expected_impact": {
        "primary_kpi": "FVからCTAへの到達率",
        "improvement_range": "+30〜80%",
        "confidence": "high",
        "confidence_reason": "ページ内の実績データに基づく"
      },
      "caution": "数値は導入事例からの引用。最新実績をマーケ担当に確認してください。",
      "briefs": {
        "designer": { ... },
        "engineer": { ... }
      }
    }
  ]
}
```

---

## 7. 実験ノート機能の追加

### 新規ファイル

```
src/dashboard/
├── app/
│   └── experiment-log/
│       └── page.tsx        # 実験ノート一覧ページ
├── components/
│   ├── ExperimentLogList.tsx
│   ├── ExperimentLogEntry.tsx
│   └── MetricsInput.tsx
└── lib/
    └── experiment-store.ts # ローカルストレージ管理
```

### experiment-store.ts

```typescript
// lib/experiment-store.ts

import type { ExperimentLog } from './types';

const STORAGE_KEY = 'publish_gate_experiment_logs';
const MAX_LOGS = 20; // Free tier limit

export function getExperimentLogs(): ExperimentLog[] {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored ? JSON.parse(stored) : [];
}

export function addExperimentLog(log: ExperimentLog): void {
  const logs = getExperimentLogs();
  logs.unshift(log);
  if (logs.length > MAX_LOGS) {
    logs.pop();
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(logs));
}

export function updateExperimentLog(id: string, updates: Partial<ExperimentLog>): void {
  const logs = getExperimentLogs();
  const index = logs.findIndex(l => l.id === id);
  if (index !== -1) {
    logs[index] = { ...logs[index], ...updates };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(logs));
  }
}
```

---

## 8. テスト更新

### types.test.ts

型定義のテストを追加:

```typescript
import { describe, it, expect } from 'vitest';
import type { Proposal, EvidenceChain, SourceTag } from './types';

describe('Proposal type', () => {
  it('should have evidence_chain with 4 steps', () => {
    const proposal: Proposal = {
      id: 1,
      category: 'trust',
      impact: 'high',
      title: 'Test',
      context: {
        business_role: 'test',
        page_strengths: [],
        element_role: 'test',
      },
      evidence_chain: {
        observation: { text: 'test', source: { type: 'fv_text' } },
        industry_trend: { text: 'test', source: { type: 'ai_knowledge' } },
        gap: { text: 'test', source: { type: 'page_structure' } },
        hypothesis: { text: 'test', source: { type: 'estimate' } },
      },
      before_after: { before: 'test', after: 'test' },
      expected_impact: {
        primary_kpi: 'test',
        improvement_range: '+10%',
        confidence: 'high',
        confidence_reason: 'test',
      },
      caution: 'test',
      briefs: {
        designer: { objective: '', changes: [], checklist: [] },
        engineer: { changes: [], test_requirements: [] },
      },
    };
    
    expect(proposal.evidence_chain).toHaveProperty('observation');
    expect(proposal.evidence_chain).toHaveProperty('industry_trend');
    expect(proposal.evidence_chain).toHaveProperty('gap');
    expect(proposal.evidence_chain).toHaveProperty('hypothesis');
  });
});
```

---

## 9. 実行順序

1. `lib/types.ts` を `types-unified.ts` で置き換え
2. ブランドカラーの一括置換
3. `IssueCard.tsx` → `ProposalCard.tsx` + 新規コンポーネント追加
4. `BriefPanel.tsx` → `BriefTabs.tsx` に変更
5. `AnalysisResult.tsx` を更新
6. `prompt-builder.ts` のJSON出力スキーマを変更
7. 実験ノート機能を追加
8. テスト更新・実行
9. E2Eテスト実行

---

## 10. 確認チェックリスト

完了したらチェック:

- [ ] types.ts が新構造になっている
- [ ] 根拠チェーン4ステップが表示される
- [ ] Before/Afterが表示される
- [ ] 依頼パックがデザイナー/エンジニア切り替え可能
- [ ] ブランドカラーが #2563EB に統一
- [ ] 期待効果・注意点が表示される
- [ ] ソースタグが表示される
- [ ] 実験ノートタブが機能する
- [ ] すべてのテストがパス
- [ ] ローカルで npm run dev して動作確認
